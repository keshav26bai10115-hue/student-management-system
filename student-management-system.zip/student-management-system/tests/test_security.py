from sms.security import hash_password, verify_password


def test_hash_is_salted_and_verifies():
    h1, h2 = hash_password("secret"), hash_password("secret")
    assert h1 != h2                      # different salts
    assert verify_password(h1, "secret")
    assert not verify_password(h1, "wrong")


def test_malformed_hash_rejected():
    assert not verify_password("not-a-valid-hash", "x")
