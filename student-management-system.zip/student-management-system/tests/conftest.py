import pytest

from sms import config
from sms.database import get_connection, init_db


@pytest.fixture
def db(tmp_path, monkeypatch):
    """Fresh temporary database for every test."""
    monkeypatch.setattr(config, "DB_NAME", str(tmp_path / "test.db"))
    init_db()
    return config.DB_NAME


@pytest.fixture
def student(db):
    from sms.services import student_service
    student_service.add_student("admin", "R1", "Asha", "CSE", "a@x.com", "Female", "Paid")
    return "R1"
