import pytest

from sms.exceptions import ValidationError
from sms.services import audit_service, auth_service


def test_valid_login_returns_role_and_logs(db):
    assert auth_service.authenticate("Admin", "admin123") == ("admin", "Admin")
    assert "logged in" in audit_service.get_recent_logs()[0][2]


def test_invalid_password_returns_none(db):
    assert auth_service.authenticate("admin", "nope") is None


def test_empty_credentials_raise(db):
    with pytest.raises(ValidationError):
        auth_service.authenticate("", "")
