import pytest

from sms.exceptions import DuplicateRecordError, ValidationError
from sms.services import student_service as s


def test_add_and_list(student):
    rows = s.list_students()
    assert rows[0][0] == "R1" and rows[0][1] == "Asha"


def test_duplicate_roll_no(student):
    with pytest.raises(DuplicateRecordError):
        s.add_student("admin", "R1", "X", "", "", "", "")


def test_mandatory_fields(db):
    with pytest.raises(ValidationError):
        s.add_student("admin", " ", "", "", "", "", "")


def test_update_and_delete(student):
    s.update_student("admin", "R1", "Asha K", "ECE", "", "Female", "Pending")
    assert s.list_students()[0][1] == "Asha K"
    s.delete_student("admin", "R1")
    assert s.list_students() == []


def test_update_missing_student(db):
    with pytest.raises(ValidationError):
        s.update_student("admin", "NOPE", "N", "", "", "", "")
