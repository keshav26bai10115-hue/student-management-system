import pytest

from sms.exceptions import ValidationError
from sms.services import academic_service as a


@pytest.mark.parametrize(
    "pct,grade", [(100, "A"), (85, "A"), (84.99, "B"), (70, "B"), (50, "C"), (49.9, "F"), (0, "F")]
)
def test_grade_boundaries(pct, grade):
    assert a.calculate_grade(pct) == grade


def test_add_marks_computes_percentage(student):
    assert a.add_marks("teacher", student, "Maths", "45", "50") == (90.0, "A")
    assert len(a.list_marks()) == 1


@pytest.mark.parametrize("obtained,maxm", [("abc", "100"), ("50", "0"), ("120", "100"), ("-1", "100")])
def test_invalid_marks(student, obtained, maxm):
    with pytest.raises(ValidationError):
        a.add_marks("teacher", student, "Maths", obtained, maxm)


def test_unknown_student(db):
    with pytest.raises(ValidationError):
        a.add_marks("teacher", "GHOST", "Maths", "50", "100")
