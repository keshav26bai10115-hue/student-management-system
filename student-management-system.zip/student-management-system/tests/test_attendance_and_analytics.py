import pytest

from sms.exceptions import ValidationError
from sms.services import academic_service, analytics_service, attendance_service as att


def test_add_attendance(student):
    att.add_attendance("teacher", student, "2025-01-15", "Present")
    assert att.list_attendance()[0][2:] == ("2025-01-15", "Present")


def test_bad_date_and_status(student):
    with pytest.raises(ValidationError):
        att.add_attendance("teacher", student, "15-01-2025", "Present")
    with pytest.raises(ValidationError):
        att.add_attendance("teacher", student, "2025-01-15", "Sleeping")


def test_distributions(student):
    att.add_attendance("t", student, "2025-01-15", "Present")
    att.add_attendance("t", student, "2025-01-16", "Present")
    att.add_attendance("t", student, "2025-01-17", "Absent")
    academic_service.add_marks("t", student, "Maths", "90", "100")
    assert analytics_service.get_attendance_distribution() == {"Present": 2, "Absent": 1}
    assert analytics_service.get_grade_distribution() == {"A": 1}


def test_cascade_delete(student):
    from sms.services import student_service
    att.add_attendance("t", student, "2025-01-15", "Present")
    student_service.delete_student("admin", student)
    assert att.list_attendance() == []
