# Student Management System (SMS)

A desktop application built with **Python, Tkinter and SQLite** for managing student records, marks, attendance and analytics, with role-based access (Admin / Teacher) and an audit trail.

## Overview
SMS replaces paper registers and scattered spreadsheets with a single secure application. Admins manage student records; teachers record marks and attendance; everyone can view charts and the audit log.

## Features
- **Secure login** – PBKDF2-HMAC-SHA256 salted password hashing
- **Role-based access** – Admin (full CRUD) vs Teacher (read-only records, can enter marks/attendance)
- **Student management** – add, update, delete, view (CRUD)
- **Academics** – marks entry with automatic percentage and grade (A/B/C/F)
- **Attendance** – Present / Absent / Late with date validation
- **Data analytics** – grade distribution bar chart and attendance pie chart (Matplotlib)
- **Audit log** – every important action is recorded with user and timestamp
- **Input validation & error handling** – friendly messages, no crashes on bad input

## Technologies Used
Python 3.9+, Tkinter (GUI), SQLite3 (storage), Matplotlib (charts), hashlib (security), pytest (testing), Git/GitHub.

## Project Structure
```
student-management-system/
├── main.py                     # Entry point
├── requirements.txt
├── README.md / statement.md
├── docs/DESIGN.md              # Requirements + UML/architecture diagrams
├── sms/
│   ├── config.py               # Constants: DB path, roles, grading rules
│   ├── exceptions.py           # Custom exceptions
│   ├── security.py             # Password hashing / verification
│   ├── database.py             # Connection manager + schema
│   ├── services/               # Business logic (no GUI code)
│   │   ├── auth_service.py
│   │   ├── student_service.py
│   │   ├── academic_service.py
│   │   ├── attendance_service.py
│   │   ├── analytics_service.py
│   │   └── audit_service.py
│   └── ui/                     # Tkinter screens
│       ├── login_window.py
│       ├── dashboard.py
│       ├── students_tab.py
│       ├── academics_tab.py
│       ├── attendance_tab.py
│       ├── analytics_tab.py
│       ├── security_tab.py
│       └── widgets.py
└── tests/                      # Unit tests (pytest)
```

## Installation & Running
```bash
git clone <your-repo-url>
cd student-management-system
python -m venv venv
venv\Scripts\activate          # Windows   (Linux/macOS: source venv/bin/activate)
pip install -r requirements.txt
python main.py
```
> Tkinter ships with Python on Windows/macOS. On Ubuntu/Debian: `sudo apt install python3-tk`.

The database (`sms_database.db`) is created automatically on first run.

**Default logins**

| Role    | Username  | Password     |
|---------|-----------|--------------|
| Admin   | `admin`   | `admin123`   |
| Teacher | `teacher` | `teacher123` |

## Testing
```bash
pytest -v
```
Tests use a temporary database, so your real data is never touched. They cover password hashing, login, student CRUD, grade boundaries, marks/date validation, cascade delete and analytics queries.

## Screenshots
_Add screenshots here (login, Core Records, Academics, Analytics, Audit Log)._
Example: `![Dashboard](docs/screenshots/dashboard.png)`

## Author
_Your Name – Reg. No. – VIT_
