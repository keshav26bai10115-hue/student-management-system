"""Password hashing utilities (PBKDF2-HMAC-SHA256 with per-user salt)."""
import hashlib
import hmac
import os

from sms import config


def hash_password(password, salt=None):
    """Return 'salt_hex:key_hex'. A new random salt is generated if none is given."""
    salt_bytes = os.urandom(config.SALT_BYTES) if salt is None else bytes.fromhex(salt)
    key = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), salt_bytes, config.PBKDF2_ITERATIONS
    )
    return f"{salt_bytes.hex()}:{key.hex()}"


def verify_password(stored_password, provided_password):
    """Check a plaintext password against a stored 'salt:key' string."""
    try:
        salt, _ = stored_password.split(":")
        candidate = hash_password(provided_password, salt)
    except ValueError:
        return False
    return hmac.compare_digest(candidate, stored_password)
