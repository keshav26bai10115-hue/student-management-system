"""Student Management System (SMS) package."""

__version__ = "1.0.0"
