"""SQLite connection handling and schema initialisation."""
import sqlite3
from contextlib import contextmanager

from sms import config
from sms.security import hash_password

SCHEMA = (
    """
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS students (
        roll_no TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        course TEXT NOT NULL,
        email TEXT,
        gender TEXT,
        fee_status TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS marks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        roll_no TEXT NOT NULL,
        subject TEXT NOT NULL,
        marks_obtained REAL NOT NULL,
        max_marks REAL NOT NULL,
        percentage REAL,
        grade TEXT,
        FOREIGN KEY (roll_no) REFERENCES students (roll_no) ON DELETE CASCADE
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS attendance (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        roll_no TEXT NOT NULL,
        date TEXT NOT NULL,
        status TEXT NOT NULL,
        FOREIGN KEY (roll_no) REFERENCES students (roll_no) ON DELETE CASCADE
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS activity_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        action TEXT NOT NULL,
        timestamp TEXT NOT NULL
    )
    """,
)


@contextmanager
def get_connection():
    """Yield a connection with foreign keys on; commit on success, rollback on error, always close."""
    conn = sqlite3.connect(config.DB_NAME)
    conn.execute("PRAGMA foreign_keys = ON;")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """Create tables and seed the default Admin/Teacher accounts (only if missing)."""
    with get_connection() as conn:
        for statement in SCHEMA:
            conn.execute(statement)
        for username, password, role in config.DEFAULT_USERS:
            conn.execute(
                "INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?) "
                "ON CONFLICT(username) DO NOTHING",
                (username, hash_password(password), role),
            )
