"""Login screen; opens the Dashboard on success."""
import tkinter as tk
from tkinter import messagebox

from sms.exceptions import SMSError
from sms.services import auth_service
from sms.ui.dashboard import Dashboard


class LoginWindow:
    def __init__(self, root):
        self.root = root
        root.title("SMS - Secure Login")
        root.geometry("380x300")
        root.resizable(False, False)

        tk.Label(root, text="Student Management System",
                 font=("Arial", 14, "bold")).pack(pady=15)

        frame = tk.Frame(root)
        frame.pack(pady=10)
        tk.Label(frame, text="Username:", font=("Arial", 10)).grid(row=0, column=0, sticky="w", pady=5)
        self.ent_username = tk.Entry(frame, width=22)
        self.ent_username.grid(row=0, column=1, pady=5)
        tk.Label(frame, text="Password:", font=("Arial", 10)).grid(row=1, column=0, sticky="w", pady=5)
        self.ent_password = tk.Entry(frame, show="*", width=22)
        self.ent_password.grid(row=1, column=1, pady=5)
        self.ent_password.bind("<Return>", lambda _e: self.login())

        tk.Button(root, text="Login", command=self.login, width=15, bg="#4CAF50",
                  fg="white", font=("Arial", 10, "bold")).pack(pady=15)
        tk.Label(root, text="Admin: admin/admin123 | Teacher: teacher/teacher123",
                 fg="gray").pack()

    def login(self):
        try:
            result = auth_service.authenticate(
                self.ent_username.get(), self.ent_password.get()
            )
        except SMSError as e:
            messagebox.showerror("Error", str(e))
            return

        if result is None:
            messagebox.showerror("Error", "Invalid credentials.")
            return

        username, role = result
        for widget in self.root.winfo_children():
            widget.destroy()
        Dashboard(self.root, username, role)
