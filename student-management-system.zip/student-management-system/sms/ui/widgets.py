"""Reusable Tkinter widgets."""
from tkinter import ttk


def create_treeview(parent, columns, headings):
    """Create a Treeview with vertical and horizontal scrollbars."""
    scroll_y = ttk.Scrollbar(parent, orient="vertical")
    scroll_x = ttk.Scrollbar(parent, orient="horizontal")
    tree = ttk.Treeview(
        parent,
        columns=columns,
        show="headings",
        yscrollcommand=scroll_y.set,
        xscrollcommand=scroll_x.set,
    )
    scroll_y.pack(side="right", fill="y")
    scroll_x.pack(side="bottom", fill="x")
    scroll_y.config(command=tree.yview)
    scroll_x.config(command=tree.xview)

    for col, head in zip(columns, headings):
        tree.heading(col, text=head)
        tree.column(col, width=100)

    tree.pack(fill="both", expand=True)
    return tree


def fill_treeview(tree, rows):
    """Replace all rows in a Treeview."""
    tree.delete(*tree.get_children())
    for row in rows:
        tree.insert("", "end", values=row)
