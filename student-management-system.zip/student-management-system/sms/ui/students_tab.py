"""Tab 1: student CRUD (Admin can edit, Teacher is read-only)."""
import tkinter as tk
from tkinter import messagebox, ttk

from sms import config
from sms.exceptions import SMSError
from sms.services import student_service
from sms.ui.widgets import create_treeview


class StudentsTab:
    def __init__(self, parent, username, role, on_data_changed=None):
        self.parent = parent
        self.username = username
        self.role = role
        self.on_data_changed = on_data_changed
        self._rows = {}  # iid -> row; avoids Tk turning "001" into 1
        self._build_form()
        self._build_table()
        self.refresh()

    # ---- layout ----
    def _build_form(self):
        form = tk.LabelFrame(self.parent, text="Student Info", font=("Arial", 10, "bold"))
        form.place(x=10, y=10, width=280, height=500)

        self.entries = {}
        for i, (label, key) in enumerate(
            [("Roll No:", "roll_no"), ("Name:", "name"), ("Course:", "course"), ("Email:", "email")]
        ):
            tk.Label(form, text=label).grid(row=i, column=0, sticky="w", padx=8, pady=8)
            ent = tk.Entry(form, width=18)
            ent.grid(row=i, column=1, padx=8, pady=8)
            self.entries[key] = ent

        tk.Label(form, text="Gender:").grid(row=4, column=0, sticky="w", padx=8, pady=8)
        self.combo_gender = ttk.Combobox(
            form, values=config.GENDER_OPTIONS, width=15, state="readonly"
        )
        self.combo_gender.grid(row=4, column=1, padx=8, pady=8)

        tk.Label(form, text="Fee Status:").grid(row=5, column=0, sticky="w", padx=8, pady=8)
        self.combo_fee = ttk.Combobox(
            form, values=config.FEE_STATUS_OPTIONS, width=15, state="readonly"
        )
        self.combo_fee.grid(row=5, column=1, padx=8, pady=8)

        if self.role == config.ROLE_ADMIN:
            btns = tk.Frame(form)
            btns.grid(row=6, columnspan=2, pady=15)
            for col, (text, cmd, color) in enumerate(
                [("Add", self.on_add, "#4CAF50"),
                 ("Update", self.on_update, "#FF9800"),
                 ("Delete", self.on_delete, "#F44336")]
            ):
                tk.Button(btns, text=text, command=cmd, width=7, bg=color, fg="white").grid(
                    row=0, column=col, padx=2
                )
            tk.Button(btns, text="Clear", command=self.clear_entries, width=24,
                      bg="#9E9E9E", fg="white").grid(row=1, columnspan=3, pady=5)
        else:
            tk.Label(form, text="[Read-Only Mode]", fg="red",
                     font=("Arial", 10, "italic")).grid(row=6, columnspan=2, pady=20)

    def _build_table(self):
        frame = tk.Frame(self.parent)
        frame.place(x=300, y=10, width=640, height=500)
        cols = ("roll_no", "name", "course", "email", "gender", "fee_status")
        heads = ("Roll No", "Name", "Course", "Email", "Gender", "Fee Status")
        self.table = create_treeview(frame, cols, heads)
        self.table.bind("<ButtonRelease-1>", self.on_row_select)

    # ---- helpers ----
    def _form_values(self):
        return (
            self.entries["roll_no"].get(),
            self.entries["name"].get(),
            self.entries["course"].get(),
            self.entries["email"].get(),
            self.combo_gender.get(),
            self.combo_fee.get(),
        )

    def _after_change(self):
        self.refresh()
        self.clear_entries()
        if self.on_data_changed:
            self.on_data_changed()

    # ---- actions ----
    def refresh(self):
        rows = student_service.list_students()
        self._rows = {str(r[0]): r for r in rows}
        self.table.delete(*self.table.get_children())
        for iid, row in self._rows.items():
            self.table.insert("", "end", iid=iid, values=row)

    def clear_entries(self):
        for entry in self.entries.values():
            entry.delete(0, tk.END)
        self.combo_gender.set("")
        self.combo_fee.set("")

    def on_row_select(self, _event):
        row = self._rows.get(self.table.focus())
        if not row:
            return
        self.clear_entries()
        for key, value in zip(("roll_no", "name", "course", "email"), row[:4]):
            self.entries[key].insert(0, value)
        self.combo_gender.set(row[4])
        self.combo_fee.set(row[5])

    def on_add(self):
        try:
            student_service.add_student(self.username, *self._form_values())
        except SMSError as e:
            messagebox.showerror("Error", str(e))
            return
        self._after_change()
        messagebox.showinfo("Success", "Student added successfully!")

    def on_update(self):
        try:
            student_service.update_student(self.username, *self._form_values())
        except SMSError as e:
            messagebox.showerror("Error", str(e))
            return
        self._after_change()
        messagebox.showinfo("Success", "Record updated successfully.")

    def on_delete(self):
        try:
            student_service.delete_student(self.username, self.entries["roll_no"].get())
        except SMSError as e:
            messagebox.showerror("Error", str(e))
            return
        self._after_change()
        messagebox.showinfo("Success", "Record deleted successfully.")
