"""Tab 3: attendance marking and history."""
import tkinter as tk
from datetime import datetime
from tkinter import messagebox, ttk

from sms import config
from sms.exceptions import SMSError
from sms.services import attendance_service
from sms.ui.widgets import create_treeview, fill_treeview


class AttendanceTab:
    def __init__(self, parent, username, role):
        self.parent = parent
        self.username = username
        self.role = role
        self._build_form()
        self._build_table()
        self.refresh()

    def _build_form(self):
        form = tk.LabelFrame(self.parent, text="Mark Attendance", font=("Arial", 10, "bold"))
        form.place(x=10, y=10, width=280, height=500)

        tk.Label(form, text="Select Roll No:").grid(row=0, column=0, sticky="w", padx=8, pady=10)
        self.combo_roll = ttk.Combobox(form, width=15, state="readonly")
        self.combo_roll.grid(row=0, column=1, padx=8, pady=10)

        tk.Label(form, text="Date (YYYY-MM-DD):").grid(row=1, column=0, sticky="w", padx=8, pady=10)
        self.ent_date = tk.Entry(form, width=18)
        self.ent_date.insert(0, datetime.now().strftime("%Y-%m-%d"))
        self.ent_date.grid(row=1, column=1, padx=8, pady=10)

        tk.Label(form, text="Status:").grid(row=2, column=0, sticky="w", padx=8, pady=10)
        self.combo_status = ttk.Combobox(
            form, values=config.ATTENDANCE_STATUSES, width=15, state="readonly"
        )
        self.combo_status.grid(row=2, column=1, padx=8, pady=10)

        if self.role in config.WRITE_ROLES:
            tk.Button(form, text="Save Attendance", command=self.on_save, bg="#2196F3",
                      fg="white", width=22).grid(row=3, columnspan=2, pady=20)

    def _build_table(self):
        frame = tk.Frame(self.parent)
        frame.place(x=300, y=10, width=640, height=500)
        self.table = create_treeview(
            frame, ("id", "roll_no", "date", "status"), ("ID", "Roll No", "Date", "Status")
        )

    def set_roll_numbers(self, rolls):
        self.combo_roll["values"] = rolls

    def refresh(self):
        fill_treeview(self.table, attendance_service.list_attendance())

    def on_save(self):
        try:
            attendance_service.add_attendance(
                self.username, self.combo_roll.get(), self.ent_date.get(), self.combo_status.get()
            )
        except SMSError as e:
            messagebox.showerror("Error", str(e))
            return
        self.refresh()
        messagebox.showinfo("Success", "Attendance logged.")
