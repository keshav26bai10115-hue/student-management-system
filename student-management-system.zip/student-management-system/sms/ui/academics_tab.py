"""Tab 2: grade entry and marks table."""
import tkinter as tk
from tkinter import messagebox, ttk

from sms import config
from sms.exceptions import SMSError
from sms.services import academic_service
from sms.ui.widgets import create_treeview, fill_treeview


class AcademicsTab:
    def __init__(self, parent, username, role):
        self.parent = parent
        self.username = username
        self.role = role
        self._build_form()
        self._build_table()
        self.refresh()

    def _build_form(self):
        form = tk.LabelFrame(self.parent, text="Grade Entry", font=("Arial", 10, "bold"))
        form.place(x=10, y=10, width=280, height=500)

        tk.Label(form, text="Select Roll No:").grid(row=0, column=0, sticky="w", padx=8, pady=10)
        self.combo_roll = ttk.Combobox(form, width=15, state="readonly")
        self.combo_roll.grid(row=0, column=1, padx=8, pady=10)

        tk.Label(form, text="Subject:").grid(row=1, column=0, sticky="w", padx=8, pady=10)
        self.ent_subject = tk.Entry(form, width=18)
        self.ent_subject.grid(row=1, column=1, padx=8, pady=10)

        tk.Label(form, text="Marks Obtained:").grid(row=2, column=0, sticky="w", padx=8, pady=10)
        self.ent_marks = tk.Entry(form, width=18)
        self.ent_marks.grid(row=2, column=1, padx=8, pady=10)

        tk.Label(form, text="Max Marks:").grid(row=3, column=0, sticky="w", padx=8, pady=10)
        self.ent_max = tk.Entry(form, width=18)
        self.ent_max.insert(0, "100")
        self.ent_max.grid(row=3, column=1, padx=8, pady=10)

        if self.role in config.WRITE_ROLES:
            tk.Button(form, text="Save Grade", command=self.on_save, bg="#4CAF50",
                      fg="white", width=22).grid(row=4, columnspan=2, pady=20)

    def _build_table(self):
        frame = tk.Frame(self.parent)
        frame.place(x=300, y=10, width=640, height=500)
        cols = ("id", "roll_no", "subject", "marks", "max_marks", "percentage", "grade")
        heads = ("ID", "Roll No", "Subject", "Obtained", "Max", "Percentage", "Grade")
        self.table = create_treeview(frame, cols, heads)

    def set_roll_numbers(self, rolls):
        self.combo_roll["values"] = rolls

    def refresh(self):
        fill_treeview(self.table, academic_service.list_marks())

    def on_save(self):
        try:
            academic_service.add_marks(
                self.username,
                self.combo_roll.get(),
                self.ent_subject.get(),
                self.ent_marks.get(),
                self.ent_max.get(),
            )
        except SMSError as e:
            messagebox.showerror("Error", str(e))
            return
        self.refresh()
        self.ent_subject.delete(0, tk.END)
        self.ent_marks.delete(0, tk.END)
        messagebox.showinfo("Success", "Grade recorded.")
