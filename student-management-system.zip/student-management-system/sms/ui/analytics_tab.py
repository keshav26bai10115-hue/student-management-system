"""Tab 4: matplotlib charts (grade distribution + attendance spread)."""
import tkinter as tk

import matplotlib

matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure

from sms import config
from sms.services import analytics_service


class AnalyticsTab:
    def __init__(self, parent):
        self.parent = parent
        tk.Button(parent, text="Refresh Visualizations", command=self.render_charts,
                  bg="#2196F3", fg="white", font=("Arial", 10, "bold")).pack(pady=10)
        self.chart_frame = tk.Frame(parent)
        self.chart_frame.pack(fill="both", expand=True)
        self.render_charts()

    def render_charts(self):
        for widget in self.chart_frame.winfo_children():
            widget.destroy()

        grade_data = analytics_service.get_grade_distribution()
        att_data = analytics_service.get_attendance_distribution()

        fig = Figure(figsize=(9, 4), dpi=100)

        ax1 = fig.add_subplot(121)
        counts = [grade_data.get(g, 0) for g in config.GRADES]
        ax1.bar(config.GRADES, counts, color=["#4CAF50", "#2196F3", "#FF9800", "#F44336"])
        ax1.set_title("Grade Distribution")
        ax1.set_xlabel("Grade")
        ax1.set_ylabel("Number of Records")

        ax2 = fig.add_subplot(122)
        labels = list(att_data.keys()) if att_data else ["No Data"]
        values = list(att_data.values()) if att_data else [1]
        ax2.pie(values, labels=labels, autopct="%1.1f%%", startangle=90)
        ax2.set_title("Overall Attendance Spread")

        fig.tight_layout()
        canvas = FigureCanvasTkAgg(fig, master=self.chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)
