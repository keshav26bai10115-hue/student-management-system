"""Tab 5: audit log viewer."""
import tkinter as tk

from sms.services import audit_service
from sms.ui.widgets import create_treeview, fill_treeview


class SecurityTab:
    def __init__(self, parent):
        self.parent = parent
        tk.Label(parent, text="System Audit & Activity Logs",
                 font=("Arial", 12, "bold")).pack(pady=10)

        frame = tk.Frame(parent)
        frame.pack(fill="both", expand=True, padx=20, pady=10)
        self.table = create_treeview(
            frame,
            ("id", "username", "action", "timestamp"),
            ("Log ID", "User", "Action Executed", "Timestamp"),
        )

        tk.Button(parent, text="Refresh Audit Log", command=self.refresh,
                  bg="#9E9E9E", fg="white").pack(pady=10)
        self.refresh()

    def refresh(self):
        fill_treeview(self.table, audit_service.get_recent_logs())
