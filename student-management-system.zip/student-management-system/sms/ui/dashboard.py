"""Main window: title bar + notebook that hosts all feature tabs."""
import tkinter as tk
from tkinter import ttk

from sms.services import student_service
from sms.ui.academics_tab import AcademicsTab
from sms.ui.analytics_tab import AnalyticsTab
from sms.ui.attendance_tab import AttendanceTab
from sms.ui.security_tab import SecurityTab
from sms.ui.students_tab import StudentsTab


class Dashboard:
    def __init__(self, root, username, role):
        self.root = root
        self.username = username
        self.role = role
        root.title(f"Student Management System - Logged in: {username} ({role})")
        root.geometry("980x640")
        root.resizable(True, True)

        header = tk.Frame(root, bg="#2196F3")
        header.pack(fill="x")
        tk.Label(header, text=f"Student Management System ({role} Panel)",
                 font=("Arial", 16, "bold"), bg="#2196F3", fg="white", pady=10).pack()

        notebook = ttk.Notebook(root)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)

        frames = {}
        for key, title in [
            ("students", "Core Records"),
            ("academics", "Academics"),
            ("attendance", "Attendance"),
            ("analytics", "Data Analytics"),
            ("security", "Security & Audit Logs"),
        ]:
            frames[key] = ttk.Frame(notebook)
            notebook.add(frames[key], text=title)

        self.academics_tab = AcademicsTab(frames["academics"], username, role)
        self.attendance_tab = AttendanceTab(frames["attendance"], username, role)
        self.students_tab = StudentsTab(
            frames["students"], username, role, on_data_changed=self.refresh_student_dropdowns
        )
        self.analytics_tab = AnalyticsTab(frames["analytics"])
        self.security_tab = SecurityTab(frames["security"])

        self.refresh_student_dropdowns()

    def refresh_student_dropdowns(self):
        """Keep roll-number dropdowns in sync after students are added/removed."""
        rolls = student_service.list_roll_numbers()
        self.academics_tab.set_roll_numbers(rolls)
        self.attendance_tab.set_roll_numbers(rolls)
