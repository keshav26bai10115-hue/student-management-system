"""Attendance recording."""
import sqlite3
from datetime import datetime

from sms import config
from sms.database import get_connection
from sms.exceptions import ValidationError
from sms.services.audit_service import log_activity


def list_attendance():
    with get_connection() as conn:
        return conn.execute("SELECT * FROM attendance").fetchall()


def add_attendance(actor, roll_no, date_str, status):
    date_str = (date_str or "").strip()
    if not roll_no or not date_str or not status:
        raise ValidationError("All fields are required.")
    if status not in config.ATTENDANCE_STATUSES:
        raise ValidationError("Invalid attendance status.")
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        raise ValidationError("Date must be in YYYY-MM-DD format.")
    try:
        with get_connection() as conn:
            conn.execute(
                "INSERT INTO attendance (roll_no, date, status) VALUES (?, ?, ?)",
                (roll_no, date_str, status),
            )
    except sqlite3.IntegrityError:
        raise ValidationError("Selected student does not exist.")
    log_activity(actor, f"Marked {status} for Roll: {roll_no} on {date_str}")
