"""Marks entry, percentage and grade calculation."""
import sqlite3

from sms import config
from sms.database import get_connection
from sms.exceptions import ValidationError
from sms.services.audit_service import log_activity


def calculate_grade(percentage):
    """Map a percentage to a letter grade using config.GRADE_THRESHOLDS."""
    for minimum, grade in config.GRADE_THRESHOLDS:
        if percentage >= minimum:
            return grade
    return config.DEFAULT_GRADE


def list_marks():
    with get_connection() as conn:
        return conn.execute("SELECT * FROM marks").fetchall()


def add_marks(actor, roll_no, subject, obtained, max_marks):
    """Validate input, compute percentage/grade and store the record."""
    try:
        obtained = float(obtained)
        max_marks = float(max_marks)
    except (TypeError, ValueError):
        raise ValidationError("Enter valid numbers for marks.")

    if max_marks <= 0:
        raise ValidationError("Max marks must be greater than zero.")
    if obtained < 0 or obtained > max_marks:
        raise ValidationError("Obtained marks must be between 0 and Max Marks.")
    subject = (subject or "").strip()
    if not roll_no or not subject:
        raise ValidationError("Fill in all fields.")

    pct = round((obtained / max_marks) * 100, 2)
    grade = calculate_grade(pct)
    try:
        with get_connection() as conn:
            conn.execute(
                "INSERT INTO marks (roll_no, subject, marks_obtained, max_marks, "
                "percentage, grade) VALUES (?, ?, ?, ?, ?, ?)",
                (roll_no, subject, obtained, max_marks, pct, grade),
            )
    except sqlite3.IntegrityError:
        raise ValidationError("Selected student does not exist.")
    log_activity(actor, f"Logged grade '{grade}' for Roll: {roll_no}, Subject: {subject}")
    return pct, grade
