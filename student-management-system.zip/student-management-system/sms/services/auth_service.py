"""Authentication logic (no UI code here)."""
from sms.database import get_connection
from sms.exceptions import ValidationError
from sms.security import verify_password
from sms.services.audit_service import log_activity


def authenticate(username, password):
    """Return (username, role) on success, or None for invalid credentials."""
    username = (username or "").strip().lower()
    password = (password or "").strip()
    if not username or not password:
        raise ValidationError("Please enter both credentials.")

    with get_connection() as conn:
        user = conn.execute(
            "SELECT password_hash, role FROM users WHERE LOWER(username)=?",
            (username,),
        ).fetchone()

    if user and verify_password(user[0], password):
        log_activity(username, f"User logged in as {user[1]}")
        return username, user[1]
    return None
