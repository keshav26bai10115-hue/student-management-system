"""Aggregate queries used by the analytics charts."""
from sms.database import get_connection


def get_grade_distribution():
    """Return {grade: count}."""
    with get_connection() as conn:
        return dict(
            conn.execute(
                "SELECT grade, COUNT(*) FROM marks GROUP BY grade ORDER BY grade"
            ).fetchall()
        )


def get_attendance_distribution():
    """Return {status: count}."""
    with get_connection() as conn:
        return dict(
            conn.execute(
                "SELECT status, COUNT(*) FROM attendance GROUP BY status"
            ).fetchall()
        )
