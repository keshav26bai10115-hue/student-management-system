"""Audit trail: who did what and when."""
from datetime import datetime

from sms import config
from sms.database import get_connection


def log_activity(username, action):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO activity_logs (username, action, timestamp) VALUES (?, ?, ?)",
            (username, action, now),
        )


def get_recent_logs(limit=config.AUDIT_LOG_LIMIT):
    with get_connection() as conn:
        return conn.execute(
            "SELECT * FROM activity_logs ORDER BY id DESC LIMIT ?", (limit,)
        ).fetchall()
