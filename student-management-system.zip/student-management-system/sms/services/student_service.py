"""CRUD operations for student records."""
import sqlite3

from sms.database import get_connection
from sms.exceptions import DuplicateRecordError, ValidationError
from sms.services.audit_service import log_activity


def list_students():
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM students").fetchall()
    return [tuple("" if v is None else v for v in row) for row in rows]


def list_roll_numbers():
    with get_connection() as conn:
        return [r[0] for r in conn.execute("SELECT roll_no FROM students")]


def add_student(actor, roll_no, name, course, email, gender, fee_status):
    roll_no, name = roll_no.strip(), name.strip()
    if not roll_no or not name:
        raise ValidationError("Roll No and Name are mandatory fields.")
    try:
        with get_connection() as conn:
            conn.execute(
                "INSERT INTO students VALUES (?, ?, ?, ?, ?, ?)",
                (roll_no, name, course.strip(), email.strip(), gender, fee_status),
            )
    except sqlite3.IntegrityError:
        raise DuplicateRecordError("A student with this Roll No already exists.")
    log_activity(actor, f"Added student: {name} (Roll: {roll_no})")


def update_student(actor, roll_no, name, course, email, gender, fee_status):
    roll_no = roll_no.strip()
    if not roll_no or not name.strip():
        raise ValidationError("Select a record and make sure Name is filled in.")
    with get_connection() as conn:
        cur = conn.execute(
            "UPDATE students SET name=?, course=?, email=?, gender=?, fee_status=? "
            "WHERE roll_no=?",
            (name.strip(), course.strip(), email.strip(), gender, fee_status, roll_no),
        )
    if cur.rowcount == 0:
        raise ValidationError("No student found with that Roll No.")
    log_activity(actor, f"Updated student Roll No: {roll_no}")


def delete_student(actor, roll_no):
    roll_no = roll_no.strip()
    if not roll_no:
        raise ValidationError("Select a record to delete.")
    with get_connection() as conn:
        cur = conn.execute("DELETE FROM students WHERE roll_no=?", (roll_no,))
    if cur.rowcount == 0:
        raise ValidationError("No student found with that Roll No.")
    log_activity(actor, f"Deleted student Roll No: {roll_no}")
