"""Central configuration: paths, roles, grading rules and UI option lists."""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_NAME = os.path.join(BASE_DIR, "sms_database.db")

# Security
PBKDF2_ITERATIONS = 100_000
SALT_BYTES = 16

# Roles
ROLE_ADMIN = "Admin"
ROLE_TEACHER = "Teacher"
WRITE_ROLES = (ROLE_ADMIN, ROLE_TEACHER)

DEFAULT_USERS = (
    ("admin", "admin123", ROLE_ADMIN),
    ("teacher", "teacher123", ROLE_TEACHER),
)

# Grading: (minimum percentage, grade). Anything below the last is DEFAULT_GRADE.
GRADE_THRESHOLDS = ((85, "A"), (70, "B"), (50, "C"))
DEFAULT_GRADE = "F"
GRADES = ("A", "B", "C", "F")

# Dropdown options
GENDER_OPTIONS = ("Male", "Female", "Other")
FEE_STATUS_OPTIONS = ("Paid", "Pending")
ATTENDANCE_STATUSES = ("Present", "Absent", "Late")

AUDIT_LOG_LIMIT = 50
