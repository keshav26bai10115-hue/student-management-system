"""Custom exceptions so the UI can show friendly messages."""


class SMSError(Exception):
    """Base class for all application errors."""


class ValidationError(SMSError):
    """Raised when user input is missing or invalid."""


class DuplicateRecordError(SMSError):
    """Raised when inserting a record that already exists."""
