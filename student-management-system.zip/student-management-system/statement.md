# Project Statement

## Problem Statement
Educational institutions often track student details, marks and attendance on paper or in disconnected spreadsheets. This causes duplicate data, calculation errors, no access control, and no record of who changed what. A simple, secure, offline-capable tool is needed to manage this data reliably.

## Scope of the Project
**In scope:** user login with roles, student CRUD, marks entry with automatic grading, attendance marking, chart-based analytics, audit logging, input validation, local SQLite storage.

**Out of scope (current version):** web/mobile access, multi-user network deployment, email notifications, report export.

## Target Users
- **Administrators** – maintain student records and review the audit log
- **Teachers** – record marks and attendance, view analytics
- **Small institutions / coaching centres** needing a lightweight desktop solution

## High-Level Features
1. Secure role-based login (PBKDF2 hashed passwords)
2. Student management (Create, Read, Update, Delete)
3. Academic records with automatic percentage and grade calculation
4. Attendance tracking (Present / Absent / Late)
5. Visual analytics (grade distribution, attendance spread)
6. Audit trail of all key actions
7. Validation and error handling on every input
