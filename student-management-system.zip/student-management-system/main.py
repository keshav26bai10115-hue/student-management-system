"""Application entry point: python main.py"""
import tkinter as tk

from sms.database import init_db
from sms.ui.login_window import LoginWindow


def main():
    init_db()
    root = tk.Tk()
    LoginWindow(root)
    root.mainloop()


if __name__ == "__main__":
    main()
