# Design Document

> Diagrams use Mermaid and render automatically on GitHub. For the PDF report, screenshot them or recreate in draw.io.

## 1. Objectives
- Provide secure, role-based access to student data
- Automate percentage/grade calculation to remove manual errors
- Give instant visual insight into performance and attendance
- Keep a tamper-evident audit trail of user actions

## 2. Functional Requirements
| ID | Module | Requirement |
|----|--------|-------------|
| FR1 | Authentication | Login with username/password; role decides available actions |
| FR2 | Student Management | Admin can add, update, delete and view students |
| FR3 | Academics | Admin/Teacher enter marks; system computes % and grade |
| FR4 | Attendance | Admin/Teacher mark Present/Absent/Late for a date |
| FR5 | Analytics | Show grade distribution and attendance charts |
| FR6 | Audit | Record and display the latest 50 actions |

**Input/Output:** forms (text, dropdowns) → validated by service layer → stored in SQLite → shown in tables/charts.

## 3. Non-Functional Requirements
| Type | Requirement |
|------|-------------|
| Security | PBKDF2-SHA256, 100k iterations, per-user salt, constant-time compare; parameterised SQL (prevents SQL injection) |
| Usability | Tabbed GUI, dropdowns instead of free text, clear error messages, Enter key to login |
| Reliability | Transactions commit/rollback automatically; foreign keys with ON DELETE CASCADE |
| Maintainability | Layered design (UI / services / data); constants in one config file; unit tests |
| Error handling | Custom exceptions (`ValidationError`, `DuplicateRecordError`) shown as message boxes |
| Logging | `activity_logs` table records user, action, timestamp |
| Resource efficiency | Connections are opened per operation and always closed |

## 4. System Architecture
```mermaid
flowchart TB
    subgraph Presentation["Presentation Layer (Tkinter)"]
        L[LoginWindow] --> D[Dashboard]
        D --> T1[StudentsTab]
        D --> T2[AcademicsTab]
        D --> T3[AttendanceTab]
        D --> T4[AnalyticsTab]
        D --> T5[SecurityTab]
    end
    subgraph Business["Business Layer (services)"]
        A[auth_service]
        S[student_service]
        AC[academic_service]
        AT[attendance_service]
        AN[analytics_service]
        AU[audit_service]
    end
    subgraph Data["Data Layer"]
        DB[(SQLite: sms_database.db)]
        SEC[security.py]
    end
    L --> A
    T1 --> S
    T2 --> AC
    T3 --> AT
    T4 --> AN
    T5 --> AU
    A --> SEC
    A & S & AC & AT & AN & AU --> DB
```

## 5. Workflow Diagram
```mermaid
flowchart TD
    Start([Start]) --> Login[Enter credentials]
    Login --> Valid{Valid?}
    Valid -- No --> Login
    Valid -- Yes --> Role{Role}
    Role -- Admin --> Full[Manage students, marks, attendance, view analytics and logs]
    Role -- Teacher --> Lim[View students, enter marks and attendance, view analytics]
    Full --> Act[Perform action]
    Lim --> Act
    Act --> Val{Input valid?}
    Val -- No --> Err[Show error message] --> Act
    Val -- Yes --> Save[Save to DB + write audit log] --> Refresh[Refresh tables/charts] --> Act
```

## 6. Use Case Diagram
(Mermaid has no native use-case diagram; this shows actors and use cases.)
```mermaid
flowchart LR
    Admin((Admin)) --> UC1([Login])
    Teacher((Teacher)) --> UC1
    Admin --> UC2([Add / Update / Delete Student])
    Admin --> UC3([View Students])
    Teacher --> UC3
    Admin --> UC4([Enter Marks])
    Teacher --> UC4
    Admin --> UC5([Mark Attendance])
    Teacher --> UC5
    Admin --> UC6([View Analytics])
    Teacher --> UC6
    Admin --> UC7([View Audit Log])
    Teacher --> UC7
```

## 7. Sequence Diagram – Adding a Student
```mermaid
sequenceDiagram
    actor Admin
    participant UI as StudentsTab
    participant SVC as student_service
    participant DB as SQLite
    participant AUD as audit_service
    Admin->>UI: Fill form, click Add
    UI->>SVC: add_student(actor, ...)
    SVC->>SVC: validate roll_no, name
    SVC->>DB: INSERT INTO students
    alt duplicate roll_no
        DB-->>SVC: IntegrityError
        SVC-->>UI: DuplicateRecordError
        UI-->>Admin: Error message
    else success
        SVC->>AUD: log_activity(...)
        AUD->>DB: INSERT INTO activity_logs
        SVC-->>UI: OK
        UI-->>Admin: Success + refreshed table
    end
```

## 8. Class / Component Diagram
```mermaid
classDiagram
    class LoginWindow { +login() }
    class Dashboard { +refresh_student_dropdowns() }
    class StudentsTab { +on_add() +on_update() +on_delete() +refresh() }
    class AcademicsTab { +on_save() +refresh() }
    class AttendanceTab { +on_save() +refresh() }
    class AnalyticsTab { +render_charts() }
    class SecurityTab { +refresh() }
    LoginWindow --> Dashboard
    Dashboard *-- StudentsTab
    Dashboard *-- AcademicsTab
    Dashboard *-- AttendanceTab
    Dashboard *-- AnalyticsTab
    Dashboard *-- SecurityTab
    StudentsTab ..> student_service
    AcademicsTab ..> academic_service
    AttendanceTab ..> attendance_service
    AnalyticsTab ..> analytics_service
    SecurityTab ..> audit_service
    LoginWindow ..> auth_service
    class student_service { <<module>> }
    class academic_service { <<module>> }
    class attendance_service { <<module>> }
    class analytics_service { <<module>> }
    class audit_service { <<module>> }
    class auth_service { <<module>> }
```

## 9. ER Diagram & Schema
```mermaid
erDiagram
    STUDENTS ||--o{ MARKS : has
    STUDENTS ||--o{ ATTENDANCE : has
    STUDENTS {
        text roll_no PK
        text name
        text course
        text email
        text gender
        text fee_status
    }
    MARKS {
        int id PK
        text roll_no FK
        text subject
        real marks_obtained
        real max_marks
        real percentage
        text grade
    }
    ATTENDANCE {
        int id PK
        text roll_no FK
        text date
        text status
    }
    USERS {
        int id PK
        text username UK
        text password_hash
        text role
    }
    ACTIVITY_LOGS {
        int id PK
        text username
        text action
        text timestamp
    }
```

## 10. Design Decisions & Rationale
- **Layered architecture** – UI never touches SQL, so logic is testable without a display.
- **SQLite** – zero-configuration, file-based, ideal for a single-machine desktop app.
- **PBKDF2 with salt** – part of the Python standard library; resists rainbow-table and brute-force attacks better than plain SHA.
- **Config file** – grading thresholds, roles and options can change in one place.
- **Custom exceptions** – separate "user made a mistake" from "program crashed".
